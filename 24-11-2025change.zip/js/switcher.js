	
//=== Switcher panal slide function	=====================//
	jQuery(document).ready(function () {	
		jQuery('.switch-btn').on('click', function () { 
			jQuery('.styleswitcher').toggleClass('active');
		});
	});
//=== Switcher panal slide function END	=====================//


//=== Color css change function	=====================//

jQuery( document ).ready(function() {
	
    // Color changer
    jQuery(".skin-1").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-1.css");
		jQuery(".logo-header img").attr("src", "images/logo-1.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-1-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-1.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-1-light.png");
        return false;
    });
    
    jQuery(".skin-2").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-2.css");
		jQuery(".logo-header img").attr("src", "images/logo-2.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-2-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-2.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-2-light.png");
        return false;
    });
    
    jQuery(".skin-3").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-3.css");
		jQuery(".logo-header img").attr("src", "images/logo-3.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-3-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-3.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-3-light.png");
        return false;
    });
	
    jQuery(".skin-4").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-4.css");
		jQuery(".logo-header img").attr("src", "images/logo-4.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-4-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-4.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-4-light.png");
        return false;
    });
	
    jQuery(".skin-5").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-5.css");
		jQuery(".logo-header img").attr("src", "images/logo-5.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-5-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-5.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-5-light.png");
        return false;
    });	
	
    jQuery(".skin-6").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-6.css");
		jQuery(".logo-header img").attr("src", "images/logo-6.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-6-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-6.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-6-light.png");
        return false;
    });
	
	
    jQuery(".skin-7").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-7.css");
		jQuery(".logo-header img").attr("src", "images/logo-7.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-7-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-7.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-7-light.png");
        return false;
    });
    
    jQuery(".skin-8").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-8.css");
		jQuery(".logo-header img").attr("src", "images/logo-8.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-8-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-8.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-8-light.png");		
        return false;
    });
    
    jQuery(".skin-9").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-9.css");
		jQuery(".logo-header img").attr("src", "images/logo-9.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-9-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-9.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-9-light.png");		
        return false;
    });
	
    jQuery(".skin-10").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-10.css");
		jQuery(".logo-header img").attr("src", "images/logo-10.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-10-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-10.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-10-light.png");		
        return false;
    });
	
    jQuery(".skin-11").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-11.css");
		jQuery(".logo-header img").attr("src", "images/logo-11.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-11-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-11.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-11-light.png");		
        return false;
    });	
	
    jQuery(".skin-12").on('click', function(){
        jQuery(".skin").attr("href", "css/skin-12.css");
		jQuery(".logo-header img").attr("src", "images/logo-12.png");
		jQuery(".footer-dark .footer-logo img").attr("src", "images/logo-12-light.png");
		jQuery(".footer-light .footer-logo img").attr("src", "images/logo-12.png");
		
		jQuery(".header-style-3 .logo-header-inner img").attr("src", "images/logo-12-light.png");
        return false;
    });				
		
		
});


